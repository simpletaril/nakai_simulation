import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Twist

class SlipDetector(Node):
    def __init__(self):
        super().__init__('slip_detector')

        # Subscribe to IMU data
        self.subscription_imu = self.create_subscription(
            Imu,
            '/data/imu',
            self.imu_callback,
            10)
        
        # Subscribe to robot's wheel velocity command (Twist topic)
        self.subscription_cmd_vel = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            10)

        # Initialize variables to store IMU and velocity data
        self.current_acceleration = None
        self.current_angular_velocity = None
        self.current_cmd_vel = None

        # Thresholds to determine slipping (adjust based on your robot and environment)
        self.linear_slip_threshold = {'x': 0.5, 'y': 0.5, 'z': 0.5}  # Linear acceleration thresholds
        self.angular_slip_threshold = {'x': 0.2, 'y': 0.2, 'z': 0.2}  # Angular velocity thresholds

    def imu_callback(self, msg: Imu):
        # Extract linear acceleration and angular velocity from IMU data
        self.current_acceleration = msg.linear_acceleration
        self.current_angular_velocity = msg.angular_velocity

        # Check if slipping is occurring
        self.check_for_slip()

    def cmd_vel_callback(self, msg: Twist):
        # Store the last command velocity
        self.current_cmd_vel = msg

    def check_for_slip(self):
        if self.current_acceleration is None or self.current_cmd_vel is None:
            return

        # Compare linear acceleration in x, y, z with expected values from cmd_vel
        self.detect_linear_slip('x')
        self.detect_linear_slip('y')
        self.detect_linear_slip('z')

        # Compare angular velocity in x, y, z with expected values from cmd_vel
        self.detect_angular_slip('x')
        self.detect_angular_slip('y')
        self.detect_angular_slip('z')

    def detect_linear_slip(self, axis):
        expected_linear = getattr(self.current_cmd_vel.linear, axis)
        actual_linear = getattr(self.current_acceleration, axis)

        if abs(actual_linear - expected_linear) > self.linear_slip_threshold[axis]:
            self.get_logger().warn(f"Slipping detected in linear {axis}-axis!")

    def detect_angular_slip(self, axis):
        expected_angular = getattr(self.current_cmd_vel.angular, axis)
        actual_angular = getattr(self.current_angular_velocity, axis)

        if abs(actual_angular - expected_angular) > self.angular_slip_threshold[axis]:
            self.get_logger().warn(f"Slipping detected in angular {axis}-axis!")

def main(args=None):
    rclpy.init(args=args)
    slip_detector = SlipDetector()

    rclpy.spin(slip_detector)

    slip_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
