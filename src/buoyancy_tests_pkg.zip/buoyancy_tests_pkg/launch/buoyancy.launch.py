from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(
            'world',
            default_value=[get_package_share_directory('buoyancy_tests_pkg'), '/worlds/ocean.world'],
            description='Path to the world file'),

        Node(
            package='gazebo_ros',
            executable='gazebo',
            name='gazebo',
            output='screen',
            arguments=[
                '-s', 'libgazebo_ros_factory.so',
                LaunchConfiguration('world')
            ]
        ),

        Node(
            package='buoyancy_tests_pkg',
            executable='model_mass_controller',
            name='model_mass_controller',
            output='screen',
            parameters=[{'param_name': 'param_value'}]  # Add your parameters here if needed
        )
    ])
