import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Get the package directory
    buoyancy_tests_pkg_share = get_package_share_directory('buoyancy_tests_pkg')

    return LaunchDescription([
        DeclareLaunchArgument(
            'sphere_name',
            default_value='simple_sphere',
            description='Name of the sphere to be spawned in Gazebo'
        ),
        DeclareLaunchArgument(
            'x', 
            default_value='0.0',
            description='X position of the sphere'
        ),
        DeclareLaunchArgument(
            'y', 
            default_value='0.0',
            description='Y position of the sphere'
        ),
        DeclareLaunchArgument(
            'z', 
            default_value='0.5',
            description='Z position of the sphere'
        ),

        # Include the spawn sphere launch file
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                PathJoinSubstitution([buoyancy_tests_pkg_share, 'launch', 'spawn_sphere.launch.py'])
            ),
            launch_arguments={
                'name': LaunchConfiguration('sphere_name'),
                'x': LaunchConfiguration('x'),
                'y': LaunchConfiguration('y'),
                'z': LaunchConfiguration('z'),
            }.items(),
        )
    ])
