import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Get the package directory
    buoyancy_tests_pkg_share = get_package_share_directory('buoyancy_tests_pkg')

    return LaunchDescription([
        DeclareLaunchArgument(
            'robot_name',
            default_value='robot_with_buoyancy',
            description='Name of the robot to be spawned'
        ),

        # Include the robot model launch
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                PathJoinSubstitution([buoyancy_tests_pkg_share, 'launch', 'spawn_robot.launch.py'])
            ),
            launch_arguments={
                'name': LaunchConfiguration('robot_name')
            }.items(),
        )
    ])
