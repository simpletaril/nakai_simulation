#include <rclcpp/rclcpp.hpp>
#include "std_msgs/msg/float32.hpp"
#include <gazebo/common/common.hh>
#include <gazebo/gazebo.hh>
#include <gazebo/msgs/msgs.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/transport/transport.hh>
#include <ignition/math/Vector3.hh>
#include <thread>

namespace gazebo {
class ModelMassControl : public ModelPlugin {
public:
  void Load(physics::ModelPtr _parent, sdf::ElementPtr _sdf) {
    if (_sdf->HasElement("name_link_to_change_mass"))
    {
      this->name_link_to_change_mass = _sdf->Get<std::string>("name_link_to_change_mass");
    } else {
      RCLCPP_WARN(rclcpp::get_logger("ModelMassControl"), "No link name given, setting default name %s",
             this->name_link_to_change_mass.c_str());
    }

    // Store the pointer to the model
    this->model = _parent;
    this->link_to_change_mass = this->model->GetLink(this->name_link_to_change_mass);

    // Listen to the update event. This event is broadcast every simulation iteration.
    this->updateConnection = event::Events::ConnectWorldUpdateBegin(
        std::bind(&ModelMassControl::OnUpdate, this));

    // Create a topic name
    std::string model_mass_topicName = "/model_mass";

    // Initialize ROS 2 node
    if (!rclcpp::ok()) {
      rclcpp::init(0, nullptr);
    }

    // Create ROS 2 node
    this->rosNode = rclcpp::Node::make_shared("model_mass_controller_rosnode");

    // Create the subscriber
    this->rosSub = this->rosNode->create_subscription<std_msgs::msg::Float32>(
        model_mass_topicName, 10,
        std::bind(&ModelMassControl::OnRosMsg, this, std::placeholders::_1));

    // Spin up the queue helper thread.
    this->rosQueueThread = std::thread(std::bind(&ModelMassControl::QueueThread, this));
    
    RCLCPP_WARN(rclcpp::get_logger("ModelMassControl"), "Loaded ModelMassControl Plugin with parent...%s, Mass Control Started ",
             this->model->GetName().c_str());
  }

  // Called by the world update start event
public:
  void OnUpdate() {
    RCLCPP_DEBUG(rclcpp::get_logger("ModelMassControl"), "Update Tick...");
  }

public:
  void SetMass(const double &_mass) {
    this->model_mass = _mass;
    // Changing the mass
    this->link_to_change_mass->GetInertial()->SetMass(this->model_mass);
    this->link_to_change_mass->UpdateMass();
    RCLCPP_WARN(rclcpp::get_logger("ModelMassControl"), "model_mass >> %f", this->model_mass);
  }

public:
  void OnRosMsg(const std_msgs::msg::Float32::SharedPtr _msg) {
    this->SetMass(_msg->data);
  }

  /// \brief ROS 2 helper function that processes messages
private:
  void QueueThread() {
    rclcpp::spin(this->rosNode);
  }

  // Pointer to the model
private:
  physics::ModelPtr model;

  // Pointer to the update event connection
private:
  event::ConnectionPtr updateConnection;

  // Mass of the model
  double model_mass = 1.0;

  /// \brief A node for ROS 2 transport
private:
  rclcpp::Node::SharedPtr rosNode;

  /// \brief A ROS 2 subscriber
private:
  rclcpp::Subscription<std_msgs::msg::Float32>::SharedPtr rosSub;

  /// \brief A thread that keeps running the ROS 2 queue
private:
  std::thread rosQueueThread;

  /// \brief Pointer to the link for changing mass
private:
  physics::LinkPtr link_to_change_mass;

private:
  std::string name_link_to_change_mass = "base_link";
};

// Register this plugin with the simulator
GZ_REGISTER_MODEL_PLUGIN(ModelMassControl)
}  // namespace gazebo
