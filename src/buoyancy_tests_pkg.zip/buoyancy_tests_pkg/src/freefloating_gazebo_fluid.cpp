#include <gazebo/common/Plugin.hh>
#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/vector3.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/PhysicsIface.hh>
#include <gazebo/physics/Model.hh>
#include <gazebo/physics/Link.hh>
#include <gazebo/physics/World.hh>
#include <gazebo/physics/PhysicsEngine.hh>
#include <freefloating_gazebo/freefloating_gazebo_fluid.h>
#include <freefloating_gazebo/hydro_model_parser.h>

using namespace std;
using namespace std::chrono_literals;

namespace gazebo
{
class FreeFloatingFluidPlugin : public ModelPlugin
{
public:
  void Load(physics::ModelPtr _model, sdf::ElementPtr _sdf) override
  {
    RCLCPP_INFO(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Loading freefloating_fluid plugin");

    this->world_ = _model->GetWorld();

    // Parse plugin options
    surface_plane_.Set(0,0,1,0); // default ocean surface plane is Z=0
    std::string fluid_topic = "current";

    if (_sdf->HasElement("surface"))
    {
      has_surface_ = true;
      // Get one surface point
      Vector3d surface_point;
      ReadVector3(_sdf->Get<std::string>("surface"), surface_point);
      // Get gravity
      const Vector3d WORLD_GRAVITY = world_->Gravity().Normalize();
      // Water surface is orthogonal to gravity
      surface_plane_.Set(WORLD_GRAVITY.X(), WORLD_GRAVITY.Y(), WORLD_GRAVITY.Z(), WORLD_GRAVITY.Dot(surface_point));
      // Push on parameter server
      node_->set_parameter(rclcpp::Parameter("surface", surface_point.Z()));
    }

    if (_sdf->HasElement("fluidTopic"))  fluid_topic = _sdf->Get<std::string>("fluidTopic");

    // Initialize subscriber to water current
    fluid_velocity_subscriber_ = node_->create_subscription<geometry_msgs::msg::Vector3>(
        fluid_topic, 10,
        [this](const geometry_msgs::msg::Vector3::SharedPtr msg) {
            FluidVelocityCallBack(msg);
        });

    // Register plugin update
    update_event_ = event::Events::ConnectWorldUpdateBegin([this]() { this->Update(); });

    // Clear existing links
    buoyant_links_.clear();
    parsed_models_.clear();

    RCLCPP_INFO(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Loaded freefloating_fluid plugin.");
  }

  void Update()
  {
    // Look for new world models
    for (const auto &model : world_->Models())
    {
      if (!model->IsStatic())
      {
        if (std::find_if(parsed_models_.begin(), parsed_models_.end(),
                        [&](const model_st &parsed){ return parsed.name == model->GetName(); })
            == parsed_models_.end())    // not in parsed models
          ParseNewModel(model);
      }
    }

    // Look for deleted world models
    auto model = parsed_models_.begin();
    while (model != parsed_models_.end())
    {
      bool still_here = false;
      for (const auto &world_model : world_->Models())
      {
        if (world_model->GetName() == model->name)
        {
          still_here = true;
          break;
        }
      }
      if (!still_here)
        RemoveModel(model);
      else
        model++;
    }

    // Apply buoyancy force and update model states
    Vector3d actual_force, cob_position, velocity_difference;
    double signed_distance_to_surface;
    for (auto &link : buoyant_links_)
    {
      // Get world position of the center of buoyancy
      cob_position = link.link->WorldPose().Pos() +
                     link.link->WorldPose().Rot().RotateVector(link.buoyancy_center);
      // Start from the theoretical buoyancy force
      Vector3d force, torque;
      if (has_surface_)
      {
        // Adjust force depending on distance to surface (very simple model)
        signed_distance_to_surface = surface_plane_.W()
                                     - surface_plane_.X() * cob_position.X()
                                     - surface_plane_.Y() * cob_position.Y()
                                     - surface_plane_.Z() * cob_position.Z();
        force = eigen2Gazebo(link.hydro.buoyancyForce(signed_distance_to_surface));
      }

      // Velocity difference in the link frame
      Eigen::Vector6d velocity;
      velocity.head<3>() = gazebo2Eigen(link.link->WorldPose().Rot().RotateVectorReverse(link.link->WorldLinearVel() - fluid_velocity_));
      velocity.tail<3>() = gazebo2Eigen(link.link->RelativeAngularVel());

      // Resulting force
      const auto dyn_force = link.hydro.hydroDynamicForce(velocity);

      // Apply force
      link.link->AddForceAtWorldPosition(force + link.link->WorldPose().Rot().RotateVector(eigen2Gazebo(dyn_force.head<3>())),
                                         cob_position);
      // Apply torque
      link.link->AddRelativeTorque(eigen2Gazebo(dyn_force.tail<3>()));

      // Publish states as odometry message
      nav_msgs::msg::Odometry state;
      state.header.frame_id = "world";
      state.header.stamp = node_->now();
      Vector3d vec;
      for (const auto &model : parsed_models_)
      {
        // Which link
        state.child_frame_id = "base_link";

        // Write absolute pose
        auto pose = model.model_ptr->WorldPose();
        state.pose.pose.position.x = pose.Pos().X();
        state.pose.pose.position.y = pose.Pos().Y();
        state.pose.pose.position.z = pose.Pos().Z();
        state.pose.pose.orientation.x = pose.Rot().X();
        state.pose.pose.orientation.y = pose.Rot().Y();
        state.pose.pose.orientation.z = pose.Rot().Z();
        state.pose.pose.orientation.w = pose.Rot().W();

        // Write relative linear velocity
        vec = model.model_ptr->RelativeLinearVel();
        state.twist.twist.linear.x = vec.X();
        state.twist.twist.linear.y = vec.Y();
        state.twist.twist.linear.z = vec.Z();
        // Write relative angular velocity
        vec = model.model_ptr->RelativeAngularVel();
        state.twist.twist.angular.x = vec.X();
        state.twist.twist.angular.y = vec.Y();
        state.twist.twist.angular.z = vec.Z();

        // Publish
        model.state_publisher->publish(state);
      }
    }
  }

  void ParseNewModel(const physics::ModelPtr &_model)
  {
    RCLCPP_INFO(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Parsing hydro for model '%s'...", _model->GetName().c_str());

    // Define new model structure: name / pointer / publisher to odometry
    model_st new_model;
    new_model.name = _model->GetName();
    new_model.model_ptr = _model;
    new_model.state_publisher = node_->create_publisher<nav_msgs::msg::Odometry>("/" + _model->GetName() + "/state", 10);
    // Tells this model has been parsed
    parsed_models_.push_back(new_model);

    // Get link properties from robot_description to add hydro effects
    if (!node_->has_parameter("/" + _model->GetName() + "/robot_description"))
      return;

    const auto previous_link_number = buoyant_links_.size();
    std::string robot_description;
    node_->get_parameter("/" + _model->GetName() + "/robot_description", robot_description);
    ffg::HydroModelParser parser;
    parser.parseLinks(robot_description);

    for (auto &link : parser.getLinks())
    {
      // Find corresponding SDF model link if any
      const auto sdf_link = std::find_if(_model->GetLinks().begin(),
                                         _model->GetLinks().end(),
                                         [&](const physics::LinkPtr &linkptr){ return linkptr->GetName() == link.first; });

      if (sdf_link != _model->GetLinks().end())
      {
        // This link is in the SDF model
        buoyant_links_.push_back({*sdf_link, link.second});
        RCLCPP_INFO(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Adding link '%s' to buoyancy list", (*sdf_link)->GetName().c_str());
      }
      else
        RCLCPP_WARN(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Link '%s' is not found in the SDF model", link.first.c_str());
    }
  }

  void RemoveModel(std::vector<model_st>::iterator &_model)
  {
    RCLCPP_INFO(rclcpp::get_logger("FreeFloatingFluidPlugin"), "Removing model '%s'", _model->name.c_str());
    parsed_models_.erase(_model);
  }

  void FluidVelocityCallBack(const geometry_msgs::msg::Vector3::SharedPtr msg)
  {
    fluid_velocity_.X() = msg->x;
    fluid_velocity_.Y() = msg->y;
    fluid_velocity_.Z() = msg->z;
  }

private:
  rclcpp::Node::SharedPtr node_{rclcpp::Node::make_shared("freefloating_fluid_plugin")};
  rclcpp::Subscription<geometry_msgs::msg::Vector3>::SharedPtr fluid_velocity_subscriber_;
  event::ConnectionPtr update_event_;
  physics::WorldPtr world_;
  std::vector<model_st> parsed_models_;
  std::vector<buoyant_link_st> buoyant_links_;
  Eigen::Vector3d fluid_velocity_;
  Plane surface_plane_;
  bool has_surface_{false};
};

GZ_REGISTER_MODEL_PLUGIN(FreeFloatingFluidPlugin)
}
